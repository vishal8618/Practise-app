package com.ceov.practiset;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {
    private Chronometer chronometer;
    private long pauseOffset;
    private boolean running;
    TextView tx_count;
    ImageView im_inc, im_dec;
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main3 );


        chronometer = findViewById( R.id.chronometer );
        tx_count = findViewById( R.id.ttextnumber );
        im_dec = findViewById( R.id.ddecrement );
        im_inc = findViewById( R.id.iincrement );
        chronometer.setFormat( "Time: %s" );
        chronometer.setBase( SystemClock.elapsedRealtime() );
        im_inc.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count >= -10 && count < 10) {
                    count = count + 1;
                    tx_count.setText( String.valueOf( count ) );
                } else if (count > 10) {
                    Toast.makeText( Main3Activity.this, "Can't add", Toast.LENGTH_SHORT ).show();
                } else {
                }
            }
        } );
        im_dec.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count > -10 && count <= 10) {
                    count = count - 1;
                    tx_count.setText( String.valueOf( count ) );
                } else if (count > 10) {
                    Toast.makeText( Main3Activity.this, "Add value greater than 1", Toast.LENGTH_SHORT ).show();
                } else {
                }
            }
        } );
        chronometer.setOnChronometerTickListener( new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                if ((SystemClock.elapsedRealtime() - chronometer.getBase()) >= 10000) {
                    chronometer.setBase( SystemClock.elapsedRealtime() );
                    Toast.makeText( Main3Activity.this, "Bing!", Toast.LENGTH_SHORT ).show();
                }
            }
        } );
    }

    public void startChronometer(View v) {
        if (!running) {
            chronometer.setBase( SystemClock.elapsedRealtime() - pauseOffset );
            chronometer.start();
            running = true;
        }
    }

    public void pauseChronometer(View v) {
        if (running) {
            chronometer.stop();
            pauseOffset = SystemClock.elapsedRealtime() - chronometer.getBase();
            running = false;
        }
    }

    public void resetChronometer(View v) {
        chronometer.setBase( SystemClock.elapsedRealtime() );
        pauseOffset = 0;

    }
}
