package com.ceov.practiset;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextView textTimer;
    private Button startButton;
    private Button resetButton;
    private Button pauseButton;
    private long startTime = 0L;
    private Handler myHandler = new Handler();
    long timeInMillies = 0L;
    long timeSwap = 0L;
    long finalTime = 0L;
    int minutes,seconds,milliseconds;
    int count=0;
    TextView tx_count;
    ImageView im_inc,im_dec;
    Button bt_add;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );


        textTimer =findViewById(R.id.text_view_countdown);
        resetButton=findViewById( R.id.button_reset );
        tx_count=findViewById( R.id.textnumber );
        im_dec=findViewById( R.id.decrement );
        im_inc=findViewById( R.id.increment);
        startButton =  findViewById(R.id.button_start_pause);


        bt_add=findViewById( R.id.add );
        startButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                startTime = SystemClock.uptimeMillis();
                myHandler.postDelayed(updateTimerMethod, 0);

            }
        });
        im_inc.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if (count>=-10 && count<10) {
                   count = count + 1;
                   tx_count.setText( String.valueOf( count ) );
               }
               else if(count>10)
               {
                   Toast.makeText( MainActivity.this, "Can't add", Toast.LENGTH_SHORT ).show();
               }
               else {}
            }
        } );
        im_dec.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count > -10 && count <=10) {
                    count = count - 1;
                    tx_count.setText( String.valueOf( count ) );
                }
                else if (count>10){
                    Toast.makeText( MainActivity.this, "Add value greater than 1", Toast.LENGTH_SHORT ).show();
                }
                else{}
            }
        } );

        resetButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 minutes=00;
                 seconds=00;
                 milliseconds=000;
                textTimer.setText("" + minutes + ":"
                        + String.format("%02d", seconds));
               // myHandler.postDelayed(updateTimerMethod, 0);
                startTime = SystemClock.uptimeMillis();
                timeInMillies=0;
                timeSwap=0;
                timeSwap += timeInMillies;
                myHandler.removeCallbacks(updateTimerMethod);
            }
        } );
        pauseButton = findViewById(R.id.button_pause);
        pauseButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                timeSwap += timeInMillies;
                myHandler.removeCallbacks(updateTimerMethod);

            }
        });

    }

    private Runnable updateTimerMethod = new Runnable() {

        public void run() {
            timeInMillies = SystemClock.uptimeMillis() - startTime;
            finalTime = timeSwap + timeInMillies;

             seconds = (int) (finalTime / 1000)*Integer.parseInt( tx_count.getText().toString() );
             minutes = seconds / 60;
            seconds = (seconds % 60);
           //  milliseconds = (int) (finalTime % 1000);
            textTimer.setText("" + minutes + ":"
                    + String.format("%02d", seconds));
            myHandler.postDelayed(this, 0);
        }

    };



    }
